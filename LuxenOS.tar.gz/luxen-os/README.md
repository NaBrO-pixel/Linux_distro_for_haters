# Luxen OS — live-build project

Debian Trixie + Cinnamon + Calamares. Goal: a distro a Windows/Mac
skeptic can install and use for a week without bouncing off it. See
design rationale inline in each config file's comments.

## Structure

```
auto/config                          # lb config parameters — run first
config/
  package-lists/
    desktop.list.chroot               # Cinnamon + essentials
    installer.list.chroot             # Calamares + deps
    firmware.list.chroot               # drivers/codecs, matches netinstall.conf
  includes.chroot/
    etc/calamares/                     # installer config (see below)
    etc/skel/Desktop/                   # populated by the hook, not stored here
  hooks/normal/
    0100-luxen-desktop-defaults.hook.chroot  # trackpad defaults, desktop icon
calamares/                            # source copy of installer config,
                                        # already mirrored into includes.chroot/
```

## Build steps (on your Dell Latitude / Debian Trixie build box)

```sh
# one-time deps
sudo apt update
sudo apt install live-build live-config live-boot

cd luxen-os
sudo lb clean --purge      # always run between attempts, per your own
                             # established workflow from Lapdroid
sudo lb config             # reads auto/config
sudo lb build               # produces live-image-amd64.hybrid.iso
```

## What's real vs. placeholder in this scaffold

**Real / functional:**
- live-build parameters (auto/config) — Debian Trixie, amd64, iso-hybrid,
  Calamares-only (no Debian Installer, avoids a dual-installer choice)
- Package lists — Cinnamon desktop, Calamares, firmware/codecs
- Calamares config — full 8-screen sequence from the design doc
- Desktop-defaults hook — dconf trackpad settings, single desktop icon

**Still placeholder / needs real work:**
- `logo.png`, `welcome.png`, slideshow tip images — no art yet
- Cinnamon panel layout tuning (taskbar pinned apps, no terminal icon
  by default) — noted in the hook but not implemented
- The first-run welcome app referenced in `finished.conf` — separate
  small project, build after this ISO boots successfully
- LightDM greeter theming — currently stock

## Next step

```sh
sudo lb build
```
then boot the resulting ISO in a VM (VirtualBox/GNOME Boxes/qemu) before
touching real hardware. First things to check: does WiFi/Bluetooth show
up in the live session, does the Calamares installer launch cleanly from
the desktop icon, does trackpad tap-to-click already work pre-install.
