// show.qml — the "rotating tips" slideshow shown on the summary/progress
// screen while packages install. This is the ONLY education a lot of
// users will absorb before they're on the desktop, so keep each slide
// to one idea, plain language, one illustration.
//
// Fill in tipN strings — keep each under ~15 words. Suggested topics
// based on the friction points we scoped (see design doc):
//   1. How to install apps (Software Manager, not terminal)
//   2. Snap a window to the side like Windows
//   3. Where settings live / how to connect Bluetooth
//   4. Reassurance: "Updates here won't break your computer" (addresses
//      the update-anxiety carryover from Windows)

import QtQuick 2.0
import calamares.slideshow 1.0

Presentation {
    id: presentation

    Timer {
        interval: 8000
        running: true
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    Slide {
        Image { source: "images/tip-appstore.png"; anchors.centerIn: parent }
        Text {
            text: "Install apps from the Software Manager — no downloads, no installers to run."
            anchors.bottom: parent.bottom
            wrapMode: Text.WordWrap
        }
    }

    Slide {
        Image { source: "images/tip-snap.png"; anchors.centerIn: parent }
        Text {
            text: "Drag a window to the edge of the screen to snap it — just like you're used to."
            anchors.bottom: parent.bottom
            wrapMode: Text.WordWrap
        }
    }

    Slide {
        Image { source: "images/tip-settings.png"; anchors.centerIn: parent }
        Text {
            text: "All your settings, including Bluetooth and WiFi, live in one place: Settings."
            anchors.bottom: parent.bottom
            wrapMode: Text.WordWrap
        }
    }

    Slide {
        Image { source: "images/tip-updates.png"; anchors.centerIn: parent }
        Text {
            text: "Updates here are tested before they reach you — they won't break your computer."
            anchors.bottom: parent.bottom
            wrapMode: Text.WordWrap
        }
    }
}
